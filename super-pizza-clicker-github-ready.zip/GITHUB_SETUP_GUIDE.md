# 🍕 Super Pizza Clicker Deluxe - GitHub Setup Guide

## Step 1: Create a GitHub Repository

1. Go to https://github.com and sign in
2. Click the **"+"** icon in the top right corner
3. Select **"New repository"**
4. Name it: `super-pizza-clicker-deluxe` (or any name you like)
5. Make it **Public** (so GitHub Pages works for free)
6. ✅ Check **"Add a README file"**
7. ✅ Check **"Add .gitignore"** and select **"Node"** from the dropdown
8. Click **"Create repository"**

## Step 2: Upload Your Files

1. In your new repository, click **"Add file"** → **"Upload files"**
2. Drag and drop ALL these files from your extracted folder:
   - `App.tsx`
   - `index.html`
   - `index.tsx`
   - `package.json`
   - `tsconfig.json`
   - `vite.config.ts`
   - `constants.ts`
   - `types.ts`
   - `utils.ts`
   - `metadata.json`
   - The `services/` folder
   - `.gitignore` file
   
   ⚠️ **DO NOT upload `.env.local`** - this contains your API key and should stay private!

3. Write a commit message: "Initial commit - Super Pizza Clicker"
4. Click **"Commit changes"**

## Step 3: Set Up GitHub Actions for Auto-Deploy

1. In your repository, click **"Actions"** tab
2. Click **"Set up a workflow yourself"**
3. Replace everything with this code:

```yaml
name: Deploy to GitHub Pages

on:
  push:
    branches: [ main ]
  workflow_dispatch:

permissions:
  contents: read
  pages: write
  id-token: write

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      
      - name: Setup Node
        uses: actions/setup-node@v4
        with:
          node-version: '20'
          
      - name: Install dependencies
        run: npm install
        
      - name: Build
        run: npm run build
        env:
          GEMINI_API_KEY: ${{ secrets.GEMINI_API_KEY }}
          
      - name: Upload artifact
        uses: actions/upload-pages-artifact@v3
        with:
          path: ./dist

  deploy:
    environment:
      name: github-pages
      url: ${{ steps.deployment.outputs.page_url }}
    runs-on: ubuntu-latest
    needs: build
    steps:
      - name: Deploy to GitHub Pages
        id: deployment
        uses: actions/deploy-pages@v4
```

4. Name the file: `deploy.yml`
5. Click **"Commit changes"**

## Step 4: Add Your API Key as a Secret

⚠️ **IMPORTANT**: Your game uses the Gemini API, so you need to add your API key securely:

1. Go to **Settings** → **Secrets and variables** → **Actions**
2. Click **"New repository secret"**
3. Name: `GEMINI_API_KEY`
4. Value: Paste your actual Gemini API key (get it from https://aistudio.google.com/apikey)
5. Click **"Add secret"**

## Step 5: Enable GitHub Pages

1. Go to **Settings** → **Pages**
2. Under **"Source"**, select **"GitHub Actions"**
3. Click **"Save"**

## Step 6: Trigger the Deploy

1. Go to the **"Actions"** tab
2. Click on the "Deploy to GitHub Pages" workflow
3. Click **"Run workflow"** → **"Run workflow"**
4. Wait 2-3 minutes for it to complete
5. Your game will be live at: `https://yourusername.github.io/super-pizza-clicker-deluxe/`

## 🎮 That's It!

Every time you push changes to your repository, it will automatically rebuild and deploy!

## Troubleshooting

**If you get a 404 error:**
- Make sure GitHub Pages source is set to "GitHub Actions" (not "main branch")
- Wait a few minutes and refresh
- Check the Actions tab to see if the deployment succeeded

**If the game doesn't work:**
- Make sure you added your `GEMINI_API_KEY` as a secret
- Check the browser console (F12) for errors
